#include "Arduino.h"
#include "LcdBarGraph.h"


// -- initializing bar segment characters
#ifndef USE_BUILDIN_FILLED_CHAR
// -- filled character
byte LcdBarGraph::_level0[8] = {
    B11111,
    B11111,
    B11111,
    B11111,
    B11111,
    B11111,
    B11111,
    B11111
};
#endif

// -- character with one bar
byte LcdBarGraph::_level1[8] = {
    B10000,
    B10000,
    B10000,
    B10000,
    B10000,
    B10000,
    B10000,
    B10000
};
// -- character with two bars
byte LcdBarGraph::_level2[8] = {
    B11000,
    B11000,
    B11000,
    B11000,
    B11000,
    B11000,
    B11000,
    B11000
};
// -- character with three bars
byte LcdBarGraph::_level3[8] = {
    B11100,
    B11100,
    B11100,
    B11100,
    B11100,
    B11100,
    B11100,
    B11100
};
// -- character with four bars
byte LcdBarGraph::_level4[8] = {
    B11110,
    B11110,
    B11110,
    B11110,
    B11110,
    B11110,
    B11110,
    B11110
};

// -- constructor
LcdBarGraph::LcdBarGraph(LiquidCrystal_I2C* lcd, byte numCols, byte startX, byte startY)
{
    // -- setting fields
    _lcd = lcd;
    _numCols = numCols;
    _startX = startX;
	_startY = startY;
}

void LcdBarGraph::begin()
{
    // -- creating characters
#ifndef USE_BUILDIN_FILLED_CHAR
    _lcd->createChar(0, this->_level0);
#endif
    _lcd->createChar(1, this->_level1);
    _lcd->createChar(2, this->_level2);
    _lcd->createChar(3, this->_level3);
    _lcd->createChar(4, this->_level4);
    // -- setting initial values
    this->_prevValue = 0; // -- cached value
    this->_lastFullChars = 0; // -- cached value
	this->_initialized = true;
}

void LcdBarGraph::setMinValue(long minValue)
{
	_minValue = minValue;
}

void LcdBarGraph::setMaxValue(long maxValue)
{
	_maxValue = maxValue;
}

// -- the draw function
void LcdBarGraph::drawValue(int value) {
	if(!this->_initialized) {
		this->begin();
	}
    // -- calculate full (filled) character count
    byte fullChars = (long)(value + _minValue) * _numCols / _maxValue;
    // -- calculate partial character bar count
    byte mod = ((long)(value + _minValue) * _numCols * 5 / _maxValue) % 5;

    // -- if value does not change, do not draw anything
    int normalizedValue = (int)fullChars * 5 + mod;
    if(this->_prevValue != normalizedValue) {
        // -- do not clear the display to eliminate flickers
        _lcd->setCursor(_startX, _startY);
        
        // -- write filled characters
        for(byte i=0; i<fullChars; i++) {
#ifdef USE_BUILDIN_FILLED_CHAR
            _lcd->write((byte)USE_BUILDIN_FILLED_CHAR);  // -- use build in filled char
#else
            _lcd->write((byte)0);
#endif
        }
        
        // -- write the partial character
        if(mod > 0) {
            _lcd->write(mod); // -- index the right partial character
            ++fullChars;
        }
        
        // -- clear characters left over the previous draw
        for(byte i=fullChars;i<this->_lastFullChars;i++) {
            _lcd->write(' ');
        }
        
        // -- save cache
        this->_lastFullChars = fullChars;
        this->_prevValue = normalizedValue;
    }
}
