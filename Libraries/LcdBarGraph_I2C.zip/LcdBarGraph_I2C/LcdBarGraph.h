#ifndef LiquidCrystal_I2CBARGRAPH_H
#define LiquidCrystal_I2CBARGRAPH_H

#include <LiquidCrystal_I2C.h>

#include "Arduino.h"

#define USE_BUILDIN_FILLED_CHAR  0xFF // -- Char 0xFF is usualy a filled character. Uncomment if you want the library to create the filled char at the expense of 26 bytes.

class LcdBarGraph
{
public:
    LcdBarGraph(LiquidCrystal_I2C* lcd, byte numCols, byte startX = 0, byte startY = 0);
    void drawValue(int value);
	void setMinValue(long minValue);
    void setMaxValue(long maxValue);
    void begin();
	
private:
    LiquidCrystal_I2C* _lcd;
    byte _numCols;
    byte _startX;
    byte _startY;
    int _prevValue;
    byte _lastFullChars;
	boolean _initialized = false;
	long _minValue = 0;
    long _maxValue = 1;

#ifndef USE_BUILDIN_FILLED_CHAR
    static byte _level0[8];
#endif
    static byte _level1[8];
    static byte _level2[8];
    static byte _level3[8];
    static byte _level4[8];
};

#endif
